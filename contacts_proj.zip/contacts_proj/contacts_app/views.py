

from django.http import HttpResponse

from django.contrib import messages
from django.shortcuts import redirect



import urllib
import base64
import matplotlib.pyplot as plt
import matplotlib
matplotlib.use("Agg")

from .models import *
import pandas as pd
import io
from django.shortcuts import render


# Create your views here.


def one(request):
    return render(request,'Home.html')

def View_Contacts(request):
    contacts = contacts_table.objects.all()
    return render(request, 'View_Contacts.html', {'contacts': contacts})

def Add_Contacts(request):
    if request.method == 'POST':
        file = request.FILES.get("csv_xlsx")

        if file is not None:
            try:
                if file.name.endswith('.csv'):
                    df = pd.read_csv(file, header=None, names=['salutation', 'name', 'phone_number'])
                elif file.name.endswith(('.xlsx', '.xls')):
                    df = pd.read_excel(file, header=None, names=['salutation', 'name', 'phone_number'])
                else:
                    message = 'Invalid file format. Please upload a CSV or Excel file.'
                    return render(request, "Add_Contacts.html", {"message": message})

          
                if set(['salutation', 'name', 'phone_number']).issubset(df.columns):
                    num_records_added = 0

                    for ind in df.index:
        
                        phone_number = str(df['phone_number'][ind])
                        if phone_number.isnumeric() and len(phone_number) == 10 and phone_number[0] not in ['0', '1']:
                            try:
                        
                                if not contacts_table.objects.filter(phone_number=phone_number).exists():
                                    sref = contacts_table.objects.create(
                                        salutation=str(df['salutation'][ind]),
                                        name=str(df['name'][ind]),
                                        phone_number=phone_number
                                    )
                                    num_records_added += 1  #
                                else:
                                    print(f"Duplicate entry for phone number: {phone_number}")
                            except Exception as e:
                                print(f"Error creating record: {str(e)}")
                        else:
                            print(f"Invalid phone number: {phone_number}")

                    if num_records_added > 0:
                        message = f'{num_records_added} out of {len(df)} records have been successfully entered.'
                    else:
                        message = 'No new records added. Duplicate phone numbers detected or all records are not in a valid format.'
                else:
                    message = 'File should have 3 mandatory columns - Salutation, Name, and contact number.'

            except Exception as e:
                message = f'Error processing the file: {str(e)}'
        else:
            message = 'No file uploaded'

        return render(request, "Add_Contacts.html", {"message": message})
    else:
        return render(request, "Add_Contacts.html")
