from django.db import models

# Create your models here.

from django.forms import ModelForm,Textarea

 

class contacts_table(models.Model):

# these are  mysq col na,es

    salutation = models.CharField(max_length=100)

    name = models.CharField(max_length=100)
    
    phone_number = models.CharField(max_length=10,unique=True)

