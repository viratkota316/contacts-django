from django.contrib import admin
from django.urls import path,include
from contacts_app import views


urlpatterns = [

path('',views.one),
path('Add_Contacts/', views.Add_Contacts),
path('View_Contacts/', views.View_Contacts),

]



